from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from ..models.core import *
from ..serializers.core import *

from ..utils.constants import *
from ..utils.response import get_response

from ..medias.file import *

from django.core.exceptions import ValidationError

import json

from django.db.models import Q

import shutil

from ..registers.core import *

class TAPIView(APIView):
    model = TModel  # Modifier le modèle ici
    serializer = TSerializer  # Modifier le sérialiseur ici
    tp = None
    #
    register.register(State, StateSerializer)

    def init(self, request):
        self.tp = t__init(request) 
        pass

    def apply_filter(self, instances):

        if instances and len(instances)>0:

            # control de la corbeille
            try:
                if self.tp.t_delete.is_include()!=True:
                    instances = instances.exclude(state__status=State.DELETED)
            except Exception as a:
                pass

            # control des updates
            try:
                if self.tp.t_update:
                    instances = instances.filter(state__updated__gt=self.tp.t_update) 
            except Exception as a:
                pass

            #control des autres filtres
            try:
                # Extraire les paramètres de requête à partir de request.data
                filter_params = self.tp.t_defaults
                # Construire les filtres dynamiques
                if filter_params:
                    for key, value in filter_params.items():

                        #control PUT case
                        if self.tp.request.method == 'PUT':
                            if key.lower().startswith("_"):
                                key = key[1:]
                            else:
                                continue

                        try:
                            value = json.loads(value)
                        except Exception as e:
                            pass
                        
                        try:
                            if isinstance(value, list):
                                # Utiliser `__in` pour les listes
                                instances = instances.filter(**{f"{key}__in": value})
                            else:
                                # Filtrer normalement pour les autres types de valeur
                                instances = instances.filter(**{key: value})
                        except Exception as e:
                            pass
            except Exception as a:
                pass
        
        return instances

    def get_queryset(self):
        instances = self.model.objects.all()
        instances = self.apply_filter(instances)
        return instances

    def get_object(self, pk):
        instances = self.model.objects.all().filter(id=pk)
        instances = self.apply_filter(instances)
        if instances and len(instances)>0:
            return instances[0]

        return None

    def get(self, request, pk=None):
        self.init(request)
        #
        """
        Endpoint GET pour récupérer un objet ou une liste d'objets.
        """
        if pk:
            # Récupérer l'objet spécifique par sa clé primaire
            instance = self.get_object(pk)
            # Sérialiser l'objet
            if instance:
                serializer = self.serializer(instance, t_params=self.tp)
                # Renvoyer la réponse avec les données sérialisées
                return get_response(tp=self.tp, data=serializer.data)
            else:
                return get_response(tp=self.tp, status_code=StatusCode.NOT_FOUND)
        else:
            # Récupérer tous les objets
            instances = self.get_queryset()

            if instances!=None :
                # Sérialiser tous les objets
                serializer = self.serializer(instances, many=True, t_params=self.tp)
                # Renvoyer la réponse avec les données sérialisées
                return get_response(tp=self.tp, data=serializer.data, count=len(instances))
            else:
                return get_response(tp=self.tp, status_code=StatusCode.NOT_FOUND)

    def post(self, request):
        self.init(request)
        #
        #return get_response(status_code=StatusCode.FORBIDDEN, data="errors")
        """
        Endpoint POST pour creer des objets.
        """
        try:
            # init matchings

            # Vérifier que les données sont envoyées sous le label "data"
            if not self.tp.t_items:
                response = self.save_item(request.data.copy())
                response_content = json.loads(response.content)
                if response.status_code == StatusCode.CREATED.value:
                    return get_response(tp=self.tp, status_code=StatusCode.CREATED, data=response_content.get('data', {}), count=1)
                else:
                    return get_response(tp=self.tp, status_code=StatusCode.FORBIDDEN, data=response_content.get('data', {}))

            #recuperation de la t_data:
            items, min_id, max_id = self.tp.get_items()

            if not isinstance(items, list):
                items = json.loads(items)

            response_data = []
            errors = []

            # Récupérer tous les fichiers envoyés
            files = request.FILES  

            # Parcourir chaque objet dans la liste des données
            for item in items:
                try:
                    if min_id!=-1 and int(item['id'])<min_id:
                        continue
                    if max_id!=-1 and int(item['id'])>max_id:
                        continue
                except Exception as e:
                    pass
                #
                response = self.save_item(item=item, files=files)
                response_content = json.loads(response.content)
                if response.status_code == StatusCode.CREATED.value:
                    response_data.append(response_content.get('data', {}))
                else:
                    errors.append(response_content.get('data', {}))

            # Vérifier s'il y a des erreurs
            if errors:
                # Si des erreurs sont présentes, retourner les erreurs
                return get_response(tp=self.tp, status_code=StatusCode.OK, data=errors) #FORBIDDEN

            # Si tous les objets sont créés avec succès, renvoyer la réponse avec les données sérialisées des objets créés
            return get_response(tp=self.tp, status_code=StatusCode.CREATED, data=response_data, count=len(response_data))
        except Exception as e:
            return get_response(status_code=StatusCode.UNAUTHORIZED, data=str(e))

    def save_item(self, item, files=None):
        try:
            """
            Endpoint POST pour créer un nouvel objet.
            """

            # Vérifier si 'state' est absent et l'initialiser avec une valeur par défaut si nécessaire
            if 'state' not in item:
                state = State(status=State.CREATED)
                state.save()
                state_serializer = StateSerializer(state)
                item['state'] = state.id 

            # Mise en place des autres éléments de matchings:
            try:
                if self.tp.t_matchings:
                    for matching in self.tp.t_matchings:
                        if matching.find in item:
                            item[matching.target] = item[matching.find]
            except Exception as e:
                return get_response(status_code=StatusCode.FORBIDDEN, data=str(e))

            try:
                if files and 'lid' in item:
                    lid = item['lid']
                    
                    model_fields = [field.name for field in self.model._meta.get_fields()]

                    for field in model_fields:
                        file_key = f"{lid}.{field}"
                        if file_key in files:
                            item[field] = files[file_key]
            except Exception as e:
                return get_response(status_code=StatusCode.FORBIDDEN, data=str(e))

            # Préparer les champs ManyToMany séparément
            many_to_many_fields = [
                field.name for field in self.model._meta.get_fields()
                if field.many_to_many
            ]
            # Stocker les valeurs ManyToMany et les retirer de l'item principal
            item_many = {}
            for field in many_to_many_fields:
                if field in item:
                    try:
                        # Toujours convertir en liste
                        if not isinstance(item[field], list):
                            # Si c'est une chaîne JSON, essayer de la convertir en liste
                            if isinstance(item[field], int):
                                item[field] = [item[field]]
                            elif isinstance(item[field], str):
                                # Charger la chaîne JSON et convertir chaque élément en int
                                try:
                                    item[field] = [int(i) for i in json.loads(item[field])]
                                except Exception as e:
                                    try:
                                        item[field] = [int(item[field])]
                                    except Exception as e:
                                        pass
                            else:
                                # Pour les autres types, on les convertit simplement en liste d'int
                                item[field] = [int(i) for i in item[field]]

                        # Sauvegarder dans item_many et retirer du principal
                        item_many[field] = item[field]
                        item.pop(field)
                    except Exception as e:
                        pass

            # Traiter les relations ForeignKey
            for field in self.model._meta.get_fields():
                if isinstance(field, models.ForeignKey) and field.name in item:
                    related_model = field.related_model
                    try:
                        # Tenter de récupérer l'instance associée à la ForeignKey
                        related_instance = related_model.objects.get(id=item[field.name])
                    except related_model.DoesNotExist:
                        # Si l'objet n'existe pas, supprimer le champ de item
                        item.pop(field.name, None)

            # Si c'est une mis à jour
            if 'id' in item:
                instance = self.get_object(item['id'])
                serializer = self.serializer(instance, data=item, partial=True, t_params=self.tp)
            else: 
                # Créer une instance du sérialiseur avec les données de la requête
                serializer = self.serializer(data=item, partial=True, t_params=self.tp)

            # Vérifier la validité du sérialiseur
            if serializer.is_valid():
                # Enregistrer l'objet dans la base de données
                instance = serializer.save()

                # Mettre à jour les champs ManyToMany en ajoutant de manière plus sûre
                for field, values in item_many.items():
                    try:
                        related_manager = getattr(instance, field)
                        # Vérifier si la relation existe et mettre à jour correctement
                        if values:
                            related_manager.set(values)  # Remplace les relations existantes
                        else:
                            related_manager.clear()  # Effacer les relations si la liste est vide
                    except Exception as e:
                        pass

                # Renvoyer la réponse avec les données sérialisées de l'objet créé
                return get_response(status_code=StatusCode.CREATED, data=serializer.data)
            # Si le sérialiseur n'est pas valide, renvoyer les erreurs
            return get_response(status_code=StatusCode.FORBIDDEN, data=serializer.errors)
        except Exception as e:
            return get_response(status_code=StatusCode.FORBIDDEN, data=str(e))

    def put(self, request, pk=None):
        self.init(request)
        #
        """
        Endpoint PUT pour mettre à jour un objet existant.
        """
        if pk:
            # Récupérer l'objet spécifique par sa clé primaire
            instance = self.get_object(pk)
            # Créer une instance du sérialiseur avec les données de la requête et l'objet existant
            serializer = self.serializer(instance, data=request.data, t_params=self.tp)
            # Vérifier la validité du sérialiseur
            if serializer.is_valid():
                # Enregistrer les modifications de l'objet dans la base de données
                serializer.save()
                # Renvoyer la réponse avec les données sérialisées de l'objet mis à jour
                return get_response(tp=self.tp, data=serializer.data)
            # Si le sérialiseur n'est pas valide, renvoyer les erreurs
            return get_response(status_code=StatusCode.FORBIDDEN, data=serializer.errors)
        else:
            if not self.tp.t_items:
                responses = []
                errors = []
                #
                instances = self.get_queryset()
                # Parcourir les instances et mettre à jour chaque objet
                for instance in instances:
                    # Créer une instance du sérialiseur avec les données de la requête et l'objet existant
                    serializer = self.serializer(instance, data=request.data, partial=True, t_params=self.tp)
                    # Vérifier la validité du sérialiseur
                    if serializer.is_valid():
                        # Enregistrer les modifications de l'objet dans la base de données
                        serializer.save()
                        responses.append(serializer.data)
                    else:
                        # Si le sérialiseur n'est pas valide, renvoyer les erreurs
                        errors.append(serializer.errors)
                
                # Vérifier s'il y a des erreurs
                if errors:
                    # Si des erreurs sont présentes, retourner les erreurs
                    return get_response(status_code=StatusCode.FORBIDDEN, data=errors, message=f"Done_Count_{len(responses)}")

                # Si tous les objets sont créés avec succès, renvoyer la réponse avec les données sérialisées des objets créés
                return get_response(tp=self.tp, status_code=StatusCode.CREATED, data=responses, message=f"Done_Count_{len(responses)}")

            #recuperation de la t_data:
            items, min_id, max_id = self.tp.get_items()

            if not isinstance(items, list):
                items = json.loads(items)

            response_data = []
            errors = []

            # Récupérer tous les fichiers envoyés
            files = request.FILES  

            # Parcourir chaque objet dans la liste des données
            for item in items:
                try:
                    if min_id!=-1 and int(item['id'])<min_id:
                        continue
                    if max_id!=-1 and int(item['id'])>max_id:
                        continue
                except Exception as e:
                    pass
                #
                response = self.save_item(item=item, files=files)
                response_content = json.loads(response.content)
                if response.status_code == StatusCode.CREATED.value:
                    response_data.append(response_content.get('data', {}))
                else:
                    errors.append(response_content.get('data', {}))

            # Vérifier s'il y a des erreurs
            if errors:
                # Si des erreurs sont présentes, retourner les erreurs
                return get_response(status_code=StatusCode.FORBIDDEN, data=errors)

            # Si tous les objets sont créés avec succès, renvoyer la réponse avec les données sérialisées des objets créés
            return get_response(tp=self.tp, status_code=StatusCode.OK, data=response_data, count=len(response_data))

    def delete(self, request, pk=None):
        self.init(request)
        #
        """
        Endpoint DELETE pour supprimer un objet existant.
        """

        if pk!=None:
            # Récupérer l'objet spécifique par sa clé primaire
            instance = self.get_object(pk)
            #
            if self.tp.t_delete.is_away():
                # Supprimer l'objet de la base de données
                
                instance.delete()
            else:
                # Move to recycler bin
                recycler_bin(instance)
            # Renvoyer une réponse indiquant que l'objet a été supprimé avec succès
            return get_response(tp=self.tp, status_code=StatusCode.OK, count=1)
        else:
            instances = self.get_queryset()
            count = len(instances)
            if count>0:
                if self.tp.t_delete.is_away():
                    instances.delete()
                else:
                    pass
                    date = datetime.utcnow()
                    for instance in instances:
                        recycler_bin(instance, date)
            return get_response(tp=self.tp, status_code=StatusCode.OK, count=count)

def recycler_bin(instance, date=datetime.now()):
    # Move to recycler bin
    instance.state.deleted = date
    instance.state.status = State.DELETED
    instance.state.save()
    instance.save()
