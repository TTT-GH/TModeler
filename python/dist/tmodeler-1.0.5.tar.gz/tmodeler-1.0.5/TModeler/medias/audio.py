import mutagen
from mimetypes import guess_type
from django.core.exceptions import ValidationError

def accept_audio(file):
    """
    Vérifie que le fichier est un audio valide.
    :param file: Fichier à vérifier
    """
    file_type = guess_type(file.name)[0]
    if file_type and file_type.startswith('audio/'):
        pass
    else:
        raise ValidationError("Le fichier téléchargé n'est pas un audio valide.")

def accept_duration_audio(file, min_duration, max_duration):
    """
    Vérifie que la durée de l'audio est dans les limites spécifiées.
    :param file: Fichier à vérifier
    :param min_duration: Durée minimale en secondes
    :param max_duration: Durée maximale en secondes
    """
    audio = mutagen.File(file)
    duration = audio.info.length
    if duration < min_duration or duration > max_duration:
        raise ValidationError(f"Durée de fichier non acceptée. Durée acceptable : {min_duration}-{max_duration} secondes.")