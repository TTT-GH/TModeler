import os
from django.core.exceptions import ValidationError
from django.core.files.images import get_image_dimensions
from mimetypes import guess_type


import os
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

import os
import uuid
from typing import Text

import json
from datetime import datetime

def isFile(path):
    try:
        if os.path.isfile(path):
            return True
    except Exception as e:
        return False

def to_file(content, tab=False, dir="tmp/streamings/"):
    try:
        if not isinstance(content, str):
            if tab:
                content = json.dumps(content, indent=4) 
            else:
                content = json.dumps(content) 

        mkdir(dir)

        # Générer un nom de fichier unique avec la date actuelle
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S-%f')
        filename = f"{timestamp}_tmp.txt"
        file_path = os.path.join(dir, filename)

        # Convertir le contenu en bytes si ce n'est pas déjà fait
        if isinstance(content, str):
            content = content.encode('utf-8')

        # Écrire le contenu dans le fichier binaire
        with default_storage.open(file_path, 'wb') as destination_file:
            destination_file.write(content)

        # Retourner le chemin absolu du fichier créé
        return file_path
    
    except Exception as e:
        raise ValidationError(f"Erreur lors de la copie du fichier : {e}")

def accept_format(file, formats):
    """
    Vérifie si le fichier a un format accepté.
    :param file: Fichier à vérifier
    :param formats: Liste des formats acceptés, ex: ['jpg', 'png', 'mp3', 'mp4']
    """
    file_format = file.name.split('.')[-1].lower()
    if file_format not in formats:
        raise ValidationError(f"Format de fichier non accepté. Formats acceptés : {', '.join(formats)}.")

def accept_size(file, min_size, max_size):
    """
    Vérifie si la taille du fichier est dans les limites spécifiées.
    :param file: Fichier à vérifier
    :param min_size: Taille minimale en octets
    :param max_size: Taille maximale en octets
    """
    file_size = file.size
    if file_size < min_size or file_size > max_size:
        raise ValidationError(f"Taille de fichier non acceptée. Taille acceptable : {min_size}-{max_size} octets.")

def validate_file_extension(value, formats):
    ext = value.name.split('.')[-1].lower()
    if ext not in formats:
        raise ValidationError(f"Format de fichier non accepté. Formats acceptés : {', '.join(formats)}.")

import os
from datetime import datetime
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

def mkdir(dir_path):
    """
    Ensure that the directory path exists, creating any missing directories recursively.
    
    :param dir_path: The directory path to ensure existence.
    """
    try:
        os.makedirs(dir_path, exist_ok=True)
        print(f"Created directory path: {dir_path}")
    except OSError as e:
        print(f"Error creating directory path {dir_path}: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise

def get_access_file_path(tmp_file, dir):
    try:
        mkdir(dir)

        # Générer un nom de fichier unique dans le répertoire spécifié avec la date actuelle
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')  # Format de date et heure actuelles
        unique_filename = default_storage.get_available_name(os.path.join(dir, f"{timestamp}_{tmp_file.name}"))
        access_file_path = os.path.join(default_storage.base_location, unique_filename)
        
        # Lire le contenu du fichier temporaire
        with tmp_file.open(mode='rb') as source_file:
            # Écrire le contenu dans le fichier d'accès
            with default_storage.open(access_file_path, 'wb') as destination_file:
                destination_file.write(source_file.read())
        
        # Retourner le chemin du fichier d'accès créé
        #return access_file_path #relative
        return default_storage.path(access_file_path) #absolute
    
    except Exception as e:
        print(f"Erreur lors de la copie du fichier : {e}")  # Affiche l'erreur pour déboguer
        raise ValidationError(f"Erreur lors de la copie du fichier : {e}")

def read_file(path):
    try:
        with open(path, 'r') as file:
            content = file.read()
        return content
    except Exception as e:
        raise IOError(f"Erreur lors de la lecture du fichier : {e}")


        
def rename_file(instance, filename, filetype, prefix):
    ext = filename.split('.')[-1]
    new_filename = f"{filetype}_{now().strftime('%Y%m%d_%H%M%S')}.{ext}"
    return os.path.join(prefix, new_filename)

def image_upload_path(instance, filename):
    return rename_file(instance, filename, 'image', 'mo/medias')

def icon_upload_path(instance, filename):
    # Define the upload path for the icon field
    return rename_file(instance, filename, 'image', 'mo/icons')

def pic_upload_path(instance, filename):
    # Define the upload path for the icon field
    return rename_file(instance, filename, 'image', 'pics')

def user_pp_upload_path(instance, filename):
    # Define the upload path for the icon field
    return rename_file(instance, filename, 'user_pp', 'users/pp/')

def raw_audio_upload_path(instance, filename):
    # Define the upload path for the icon field
    return rename_file(instance, filename, 'raw_voices', 'collectors/voices')

def file_upload_path(instance, filename, sub_dir=""):
    """
    Génère un chemin pour stocker le fichier en ajoutant un horodatage unique au nom du fichier.
    
    :param instance: L'instance du modèle en cours.
    :param filename: Le nom original du fichier téléchargé.
    :param sub_dir: (Optionnel) Sous-dossier où enregistrer le fichier.
    :return: Chemin d'upload avec un nom unique pour le fichier.
    """
    time = datetime.utcnow().strftime('%Y-%m-%d_%H-%M-%S-%fZ')

    # Obtenir l'extension du fichier
    extension = os.path.splitext(filename)[1]
    
    # Générer un horodatage lisible jusqu'au millième de seconde
    #timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]  # Retirer les 3 derniers chiffres de microsecondes
    
    # Créer un nom de fichier unique
    unique_filename = f"{time}{extension}"
    
    # Construire le chemin d'upload
    if sub_dir:
        return os.path.join(sub_dir, unique_filename)
    return unique_filename


def media_path(sub_dir=""): 
    def generate_path(instance, filename):
        """
        Génère un chemin pour stocker le fichier en ajoutant un horodatage unique au nom du fichier.
        
        :param instance: L'instance du modèle en cours.
        :param filename: Le nom original du fichier téléchargé.
        :return: Chemin d'upload avec un nom unique pour le fichier.
        """
        # Obtenir l'extension du fichier
        extension = os.path.splitext(filename)[1]
        
        # Générer un horodatage lisible jusqu'au millième de seconde
        time = datetime.utcnow().strftime('%Y-%m-%d_%H-%M-%S-%fZ')
        
        # Créer un nom de fichier unique
        unique_filename = f"{time}{extension}"
        
        # Construire le chemin d'upload
        return os.path.join(sub_dir, unique_filename)
    
    return generate_path