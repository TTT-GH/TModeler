from PIL import Image
from mimetypes import guess_type
from django.core.exceptions import ValidationError

def accept_image(file):
    """
    Vérifie que le fichier est une image valide.
    :param file: Fichier à vérifier
    """
    try:
        img = Image.open(file)
        img.verify()
    except (IOError, SyntaxError) as e:
        raise ValidationError("Le fichier téléchargé n'est pas une image valide.")

def accept_ratio_image(file, ratio):
    """
    Vérifie que l'image correspond à un ratio spécifié.
    :param file: Fichier à vérifier
    :param ratio: Ratio souhaité, ex: '1:1', '16:9'
    """
    img = Image.open(file)
    width, height = img.size
    expected_ratio = tuple(map(int, ratio.split(':')))
    actual_ratio = width / height

    if not (abs(actual_ratio - (expected_ratio[0] / expected_ratio[1])) < 0.1):
        raise ValidationError(f"Le ratio de l'image doit être {ratio}.")