from moviepy.editor import VideoFileClip
from mimetypes import guess_type
from django.core.exceptions import ValidationError
import os
from moviepy.editor import VideoFileClip
from fractions import Fraction

import subprocess
import os
from fractions import Fraction

def accept_video(file):
    """
    Vérifie que le fichier est une vidéo valide.
    :param file: Fichier à vérifier
    """
    file_type = guess_type(file.name)[0]
    if file_type and file_type.startswith('video/'):
        pass
    else:
        raise ValidationError("Le fichier téléchargé n'est pas une vidéo valide.")




def accept_ratio_video(file_path, ratio):
    """
    Vérifie que la vidéo correspond à un ratio spécifié.
    :param file: Fichier à vérifier
    :param ratio: Ratio souhaité, ex: '16:9'
    """
    video = VideoFileClip(file_path)
    width, height = video.size
    expected_ratio = tuple(map(int, ratio.split(':')))
    actual_ratio = width / height

    if not (abs(actual_ratio - (expected_ratio[0] / expected_ratio[1])) < 0.1):
        raise ValidationError(f"Le ratio de la vidéo doit être {ratio}.")

def accept_duration_video(file_path, min_duration, max_duration):
    """
    Vérifie que la durée de la vidéo est dans les limites spécifiées.
    :param file: Fichier à vérifier
    :param min_duration: Durée minimale en secondes
    :param max_duration: Durée maximale en secondes
    """
    video = VideoFileClip(file_path)
    duration = video.duration
    if duration < min_duration or duration > max_duration:
        raise ValidationError(f"Durée de fichier non acceptée. Durée acceptable : {min_duration}-{max_duration} secondes.")