from django.apps import AppConfig

class TModelerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TModeler'