from django.db import models
from django.utils import timezone
from datetime import datetime

# ------- 

class State(models.Model):
    CREATED = 0
    UPLOADED = 1
    PERMISSION = 2
    GRANTED = 3
    DENIED = 4
    LOADED = 5
    STARTED = 6
    ENDED = 7
    CANCELED = 8
    STOPPED = 9
    ENABLED = 10
    DISABLED = 11
    CONNECTED = 12
    DISCONNECTED = 13
    UPDATED = 14
    DONE = 15
    DELETED = 16
    RESPONSE = 17

    STATUS_CHOICES = [
        (CREATED, 'Created'),
        (UPLOADED, 'Uploaded'),
        (PERMISSION, 'Permission'),
        (GRANTED, 'Granted'),
        (DENIED, 'Denied'),
        (LOADED, 'Loaded'),
        (STARTED, 'Started'),
        (ENDED, 'Ended'),
        (CANCELED, 'Canceled'),
        (STOPPED, 'Stopped'),
        (ENABLED, 'Enabled'),
        (DISABLED, 'Disabled'),
        (CONNECTED, 'Connected'),
        (DISCONNECTED, 'Disconnected'),
        (UPDATED, 'Updated'),
        (DONE, 'Done'),
        (DELETED, 'Deleted'),
        (RESPONSE, 'Response'),
    ]

    status = models.IntegerField(choices=STATUS_CHOICES, blank=True, null=True)

    created = models.DateTimeField(null=True, blank=True)
    uploaded = models.DateTimeField(null=True, blank=True)
    permission = models.DateTimeField(null=True, blank=True)
    granted = models.DateTimeField(null=True, blank=True)
    denied = models.DateTimeField(null=True, blank=True)
    loaded = models.DateTimeField(null=True, blank=True)
    started = models.DateTimeField(null=True, blank=True)
    ended = models.DateTimeField(null=True, blank=True)
    canceled = models.DateTimeField(null=True, blank=True)
    stopped = models.DateTimeField(null=True, blank=True)
    enabled = models.DateTimeField(null=True, blank=True)
    disabled = models.DateTimeField(null=True, blank=True)
    connected = models.DateTimeField(null=True, blank=True)
    disconnected = models.DateTimeField(null=True, blank=True)
    updated = models.DateTimeField(null=True, blank=True)
    done = models.DateTimeField(null=True, blank=True)
    deleted = models.DateTimeField(null=True, blank=True)
    response = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.id:
            self.created = timezone.now()
        self.updated = timezone.now()
        super().save(*args, **kwargs)

# ----------------------------------------------------------------

class TModel(models.Model):
    lid = models.IntegerField(default=-1, blank=True, null=True)
    state = models.OneToOneField(State, on_delete=models.CASCADE, default=None, blank=True, null=True)

    """class Meta:
        abstract = True"""

    class Meta:
        abstract = True
        #ordering = ['-state__created']
        ordering = ['-id']

    def save(self, *args, **kwargs):
        if not self.state_id:
            state = State(status=State.CREATED)
            state.save()
            self.state = state
        else:
            self.state.updated = datetime.utcnow() #timezone.now()
            self.state.save()
        super().save(*args, **kwargs)

#----------------------------------------------------------------------------------------