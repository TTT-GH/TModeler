from rest_framework.response import Response
from rest_framework import status

from django.http import JsonResponse

from .constants import *

from ..medias.file import *
from datetime import datetime

import sys

def get_response_data(data,message,response_data=ResponseData.TEXT,tp=None,time=None,count=None):
    data_dict= {}

    if message is not None:
        data_dict['message'] = message
        if tp:
            data_dict['message'] = f"{message}"
            #data_dict['message'] = f"{message}_{tp.t_defaults}"
    if time is not None:
        data_dict['time'] = time
    if count is not None:
        data_dict['count'] = count
    if data is not None:
        data_dict['length'] = len(str(data))
    if data is not None:
        if response_data==ResponseData.TEXT or len(str(data))<3: # MIN_LENGTH = 1Mo
            data_dict['data'] = data
        elif response_data==ResponseData.FILE:
            data_dict['stream'] = True
            data_dict['data'] = to_file(data, tp.t_response.tab)
    
    return data_dict if data_dict else None

def get_response(tp=None, status_code=StatusCode.OK, data=None, message=None,response_data=ResponseData.TEXT,time=None,count=None):

    if not message:
        if status_code == StatusCode.NOT_FOUND:
            message = 'Resource not found!!'
        elif status_code == StatusCode.UNAUTHORIZED:
            message = 'User not authorised!!'
        elif status_code == StatusCode.FORBIDDEN:
            message = 'Action Forbidden!!'
        elif status_code == StatusCode.CREATED:
            message = 'Created!!'
        elif status_code == StatusCode.OK:
            message = 'Done!!'

    if tp:
        response_data = tp.t_response.get_container()

    if not time:
        # Heure en UTC
        # this update is necessary | to use UTC trough all system, all projects
        #utc_time = datetime.utcnow()
        #local_server_time = datetime.now()
        #time = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%f')
        time = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')

    result = get_response_data(data=data,message=message,response_data=response_data,tp=tp,time=time,count=count)
    
    return JsonResponse(result if isinstance(result, dict) else {}, status=status_code.to_http())