from datetime import datetime

def str_to_date(date_str):
    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",   # Format ISO avec microsecondes et 'Z'
        "%Y-%m-%dT%H:%M:%S.%f",    # Format ISO avec microsecondes
        "%Y-%m-%dT%H:%M:%S",       # Format ISO sans microsecondes
        "%Y-%m-%d %H:%M:%S.%f",    # Date et heure avec microsecondes
        "%Y-%m-%d %H:%M:%S",       # Date et heure sans microsecondes
        "%Y-%m-%d",                # Date seule
        "%d/%m/%Y",                # Format européen (jour/mois/année)
        "%m/%d/%Y",                # Format américain (mois/jour/année)
        "%d-%m-%Y",                # Format européen avec tirets (jour-mois-année)
        "%m-%d-%Y",                # Format américain avec tirets (mois-jour-année)
        "%d.%m.%Y",                # Format européen avec points (jour.mois.année)
        "%m.%d.%Y",                # Format américain avec points (mois.jour.année)
        "%Y/%m/%d",                # Format ISO avec barres obliques (année/mois/jour)
        "%Y-%m-%dT%H:%M:%SZ",      # Format ISO avec 'Z'
        "%Y-%m-%dT%H:%M:%S.%f%z",  # Format ISO avec microsecondes et décalage horaire
        "%Y-%m-%dT%H:%M:%S%z"      # Format ISO sans microsecondes avec décalage horaire
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            pass
    raise ValueError(f"Date format for '{date_str}' is not supported.")