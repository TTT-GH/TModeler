from enum import Enum
from rest_framework import status


import json
from datetime import datetime
from ..medias.file import *
from ..utils.date import *

#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


class StatusCode(Enum):
    OK = status.HTTP_200_OK
    CREATED = status.HTTP_201_CREATED
    FORBIDDEN = status.HTTP_403_FORBIDDEN
    NOT_FOUND = status.HTTP_404_NOT_FOUND
    UNAUTHORIZED = status.HTTP_401_UNAUTHORIZED
    
    def to_http(self):
        return self.value

class ResponseData(Enum):
    TEXT = 0
    FILE = 1
    
    def to_http(self):
        return self.value

#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        
def rename_file(instance, filename, filetype, prefix):
    ext = filename.split('.')[-1]
    new_filename = f"{filetype}_{now().strftime('%Y%m%d_%H%M%S')}.{ext}"
    return os.path.join('files', prefix, new_filename)

def icon_upload_path(instance, filename):
    # Define the upload path for the icon field
    return f"files/mo/icons/{filename}"

def user_pp_upload_path(instance, filename):
    # Define the upload path for the icon field
    return f"files/users/pp/{filename}"

def raw_audio_upload_path(instance, filename):
    # Define the upload path for the icon field
    return f"files/collectors/audios/{filename}"


#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


tp = None


#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


def t__init(request):
    try:
        tp = TParams(request)
    except Exception as e:
        pass
    return tp


#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


# Modèle Matching
class TParams:
    t_defaults = None
    t_response = None       ##cont=(TEXT, FILE), tab(True, False)    #cont=container
    t_matchings = None      ##[matching]
    t_items = None          ##[data]
    t_update = None         #date recuperation des mises à jours
    t_delete = None         ##dest(RBIN, AWAY), get(False, True)     #dest=destination RBIN recycler bin AWAY drop
    t_visib = None          ##[visibility] => futur can control visibility anyone, state by default
    
    min_id = -1
    max_id = -1

    def __init__(self, request):
        self.request = request
        self.t_defaults = self.handle_requests(request)
        try:
            self.t_response = self.init_response(request)    #
        except Exception as e:
            pass
        try:
            self.t_matchings = self.init_matchings(request)  #
        except Exception as e:
            pass
        try:
            self.t_items, self.min_id, self.max_id = self.init_items(request)          #
        except Exception as e:
            pass
        try:
            self.t_update = self.init_update(request)        #
        except Exception as e:
            pass
        try:
            self.t_delete = self.init_delete(request)        #
        except Exception as e:
            pass
        try:
            self.t_visib = self.init_visibility(request)        #
        except Exception as e:
            pass

    def handle_requests(self, request):
        params = {}

        # Vérifiez si des données sont envoyées via GET
        if request.method == 'GET':
            for key, value in request.GET.items():
                params[key] = value
            for key, value in request.data.items():
                params[key] = value

        # Vérifiez si des données sont envoyées via POST
        elif request.method == 'POST':
            for key, value in request.POST.items():
                params[key] = value
            for key, value in request.data.items():
                params[key] = value

        # Vérifiez si des données sont envoyées via PUT
        elif request.method == 'PUT':
            for key, value in request.data.items():
                params[key] = value

        # Vérifiez si des données sont envoyées via DELETE
        elif request.method == 'DELETE':
            for key, value in request.data.items():
                params[key] = value
        
        # Ajouter les en-têtes #hesite encore...
        # default upcase first char of key
        # doesn't accept "_"
        #headers = {}
        for key, value in request.headers.items():
            params[key.lower()] = value
            #headers[key] = value
        #params['headers'] = headers

        return params

    def is_visible(self, label):
        data = str(self.t_visib).lower()
        return data and data==label

    def get_visibilities(self):
        data = self.t_visib
        return data

    def get_items(self):
        return self.t_items, self.min_id, self.max_id

    def init_response(self, request):
        data = self.get_data(request, label="t_response")
        t_param = None

        try:
            data = json.loads(data)
            #
            cont = None
            tab = None
            if 'cont' in data:
                cont = data.get('cont')
            if 'tab' in data:
                tab = data.get('tab')
            t_param = TResponse(cont=cont, tab=str(tab).lower()=="true")
        except Exception as e:
            pass

        if t_param is None and data is not None:
            data = str(data)
            data = data.lower()
            if data=="text" or data=="file":
                t_param = TResponse(cont=data)
            if data=="false" or data=="true":
                t_param = TResponse(tab=(data=="true"))

        if t_param is None:
            t_param = TResponse()
        
        return t_param

    def init_delete(self, request):
        data = self.get_data(request, label="t_delete")
        t_param = None

        try:
            data = json.loads(data)
            #
            dest = None
            get = None
            if 'dest' in data:
                dest = data.get('dest')
            if 'inc' in data:
                inc = data.get('inc')
            t_param = TDelete(dest=dest, inc=inc)
        except Exception as e:
            pass

        if t_param is None and data is not None:
            data = str(data)
            data = data.lower()
            if data=="rbin" or data=="away":
                t_param = TDelete(dest=data)
            if data=="false" or data=="true":
                t_param = TDelete(inc=(data=="true"))

        if t_param is None:
            t_param = TDelete()
        
        return t_param

    def init_update(self, request):
        data = self.get_data(request, label="t_update")
        try:
            #t_param = datetime.strptime(data, "%Y-%m-%d %H:%M:%S")
            t_param = str_to_date(data)
        except Exception as e:
            pass
            
        return t_param

    def init_visibility(self, request):
        data = self.get_data(request, label="t_visib")
        if not data:
            data = self.get_data(request, label="t_visibilities")

        """if data:
            data = str(data).lower()"""

        t_param = None

        try:
            t_param = json.loads(data)
        except Exception as e:
            pass

        if data and not t_param or not isinstance(t_param, list):
            t_param = []
            t_param.append(data)

        return t_param

    def init_items(self, request):
        min_id = -1
        max_id = -1

        t_items = self.get_data(request, label="t_items")
        print(t_items)
        t_items = json.loads(t_items)
        
        if isinstance(t_items, dict):
            if 'path' in t_items:
                file_data = read_file(t_items['path'])
                file_data = json.loads(file_data)
                if 'id' in t_items and len(t_items['id'])>0:
                    if isinstance(file_data, list):
                        for elt in file_data:
                            if t_items['id'] in elt:
                                items_datas = elt[t_items['id']]
                    else:
                        if t_items['id'] in file_data:
                            items_datas = file_data[t_items['id']]
                else:
                    items_datas = file_data

                if 'min_id' in t_items:
                    min_id = t_items['min_id']
                if 'max_id' in t_items:
                    max_id = t_items['max_id']
        elif isinstance(t_items, list):
            items_datas = t_items

        return items_datas, min_id, max_id

    def init_matchings(self, request):
        matchings_datas = self.get_data(request, label="t_matchings")
        matchings = []
        try:
            matchings_json = json.loads(matchings_datas)

            # Parcourir les données JSON et créer des objets Matching
            for matching_data in matchings_json:
                find = matching_data.get('find')
                target = matching_data.get('target')
                matching_obj = TMatching(find=find, target=target)
                matchings.append(matching_obj)
        except Exception as e:
            matchings = None
        return matchings

    def get_data(self, request, label):
        try:
            return self.t_defaults[label]
        except Exception as e:
            return None

        return None
        
    def to_dict(self):
        resp = None
        mat = None
        ite = None
        upd = None
        dele = None
        sta = None
        try:
            resp = self.t_response.to_dict()
        except Exception as e:
            pass
        try:
            mat = len(self.t_matchings)
        except Exception as e:
            pass
        try:
            ite = len(self.t_items)
        except Exception as e:
            pass
        try:
            upd = self.t_update
        except Exception as e:
            pass
        try:
            dele = self.t_delete.to_dict()
        except Exception as e:
            pass
        try:
            vis = self.t_visib
        except Exception as e:
            pass
        return {
            't_response': resp,
            't_matchings': mat,
            't_items': ite,
            't_update': upd,
            't_delete': dele,
            't_visib': vis
        }

#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

# Modèle TResponse
class TResponse:
    def __init__(self, cont="TEXT", tab=False):
        self.cont = cont
        self.tab = tab
        
    def to_dict(self):
        return {
            'cont': self.cont,
            'tab': self.tab
        }

    def get_container(self):
        if str(self.cont).lower()=="file":
            return ResponseData.FILE
        else:
            return ResponseData.TEXT

# Modèle TMatching
class TMatching:
    def __init__(self, find=None, target=None):
        self.find = find
        self.target = target
        
    def to_dict(self):
        return {
            'find': self.find,
            'target': self.target
        }

# Modèle TDelete
class TDelete:
    def __init__(self, dest="RBIN", inc=False):
        self.dest = dest
        self.inc = inc
        
    def to_dict(self):
        return {
            'dest': self.dest,
            'inc': self.inc
        }
    
    def is_away(self):
        return self.dest.lower()=="away"
    
    def is_include(self):
        return self.inc

#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>