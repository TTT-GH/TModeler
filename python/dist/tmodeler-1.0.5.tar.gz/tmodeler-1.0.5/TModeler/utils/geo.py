
import pluscodes
from openlocationcode import openlocationcode as olc

def coodo_to_plus_code(latitude, longitude):
    plus_code = pluscodes.encode(latitude, longitude)
    return plus_code

def coodo_from_plus_code(plus_code):
    area = olc.decode(plus_code)
    latitude = (area.latitudeLo + area.latitudeHi) / 2
    longitude = (area.longitudeLo + area.longitudeHi) / 2
    return latitude, longitude
