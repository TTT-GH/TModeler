from django.core.exceptions import ValidationError
from django.db import models
from django.core.files import File
import os

"""
class TFileField(models.FileField):
    def pre_save(self, model_instance, add):
        file = super().pre_save(model_instance, add)
        value = getattr(model_instance, self.attname)

        value = str(value)
        
        if isinstance(value, str):
            # Check if the path exists
            if os.path.exists(value):
                print(f"-------->File {value} exists")
                # Load the file from the path
                with open(value, 'rb') as f:
                    file = File(f)
                    # Save the file to the field
                    self.save_form_data(model_instance, file)
            else:
                raise ValidationError(f"The file at {value} does not exist.")
        
        return file

    def save_form_data(self, instance, data):
        if isinstance(data, str):
            # Set the field value to the path
            setattr(instance, self.name, data)
        else:
            # Save the file normally
            super().save_form_data(instance, data)"""


class TFileField(models.FileField):
    def pre_save(self, model_instance, add):
        print("-------->pre_save called")
        file = super().pre_save(model_instance, add)
        print("-------->super().pre_save called")
        value = getattr(model_instance, self.attname)
        print("-------->Value obtained:", value)

        print("-------->HERE")

        value = str(value)

        if isinstance(value, str):
            print("-------->Value is a string")
            if os.path.exists(value):
                print(f"-------->File {value} exists")
                with open(value, 'rb') as f:
                    file = File(f)
                    self.save_form_data(model_instance, file)
            else:
                print(f"-------->The file at {value} does not exist.")
                raise ValidationError(f"The file at {value} does not exist.")
        
        return file