from rest_framework import serializers
from ..models.core import *
from ..registers.core import *


class StateSerializer(serializers.ModelSerializer):
    description = serializers.SerializerMethodField()

    class Meta:
        model = State
        fields = '__all__'

    def get_description(self, obj):
        if obj.status == State.CREATED:
            return 'Created'
        # Ajouter d'autres descriptions en fonction du statut si nécessaire
        return dict(State.STATUS_CHOICES).get(obj.status, '')

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # Filtrer les champs pour n'inclure que ceux qui ne sont pas nuls
        filtered_representation = {key: value for key, value in representation.items() if value is not None}
        return filtered_representation

class TSerializer(serializers.ModelSerializer):
    tp = None

    def __init__(self, *args, **kwargs):
        # Extraire le paramètre perso des kwargs, avec une valeur par défaut de None
        self.tp = kwargs.pop('t_params', None)

        # Appeler le constructeur de la superclasse
        super(TSerializer, self).__init__(*args, **kwargs)
    
    class Meta:
        model = TModel
        fields = '__all__'

    """
    def validate_file(self, value):
        # Ici, vous pouvez implémenter votre propre logique de validation pour le champ 'file'
        # Par exemple, vérifier le type de fichier, la taille, etc.
        return value  # Retourner simplement la valeur sans validation"""

    def to_representation(self, instance):
        # Appel de la méthode de la superclasse pour obtenir la représentation par défaut
        representation = super(TSerializer, self).to_representation(instance)
        
        try:
            if self.tp and self.tp.get_visibilities():
                for target_label in self.tp.get_visibilities():
                    if target_label:
                        # Ajouter la représentation sérialisée du champ target_label
                        target_instance = getattr(instance, target_label, None)
                        #
                        if target_instance:
                            # Récupérer le serializer pour le label cible
                            serializer = register.get_serializer(target_instance.__class__.__name__.lower(), target_instance)
                            representation[target_label] = serializer.data
                        #
                        # Supprimer le champ 'state' de la représentation, when set with : #state = StateSerializer()
                        #representation.pop('state', None)
        except Exception as e:
            pass
        
        return representation

    