from collections import defaultdict

class SerializerRegistry:
    def __init__(self):
        self.serializers = defaultdict(dict)

    def register(self, model_class, serializer_class):
        label = model_class.__name__.lower()

        if label not in self.serializers:
            self.serializers[label] = {}

        if model_class in self.serializers[label]:
            return
        
        self.serializers[label][model_class] = serializer_class

    def get_serializer(self, label, instance):
        model_class = type(instance)
        if model_class in self.serializers[label]:
            return self.serializers[label][model_class](instance)
        return None

# Créer une instance de SerializerRegistry pour l'utiliser dans votre application
register = SerializerRegistry()